from gi.repository import GLib
from pydbus import SystemBus
import os
import pickle

loop = GLib.MainLoop()

class SecretManager():
  """
  <node>
     <interface name='net.minthe.SecretManager'>
       <method name='GetSecret'>
         <arg type='s' name='name' direction='in'/>
         <arg type='s' name='secret' direction='out'/>
       </method>
       <method name='SetSecret'>
         <arg type='s' name='name' direction='in'/>
         <arg type='s' name='secret' direction='in'/>
         <arg type='s' name='sout' direction='out'/>
       </method>
       <method name='HasSecret'>
         <arg type='s' name='name' direction='in'/>
         <arg type='b' name='has_secret' direction='out'/>
       </method>
     </interface>
   </node>
  """

  secrets = {}

  def __init__(self):
      try:
          with open(os.path.expanduser('~/.kv-secrets'), 'rb') as f:
              self.secrets = pickle.load(f)
      except IOError:
          pass

  def HasSecret(self, name):
      return name in self.secrets

  def GetSecret(self, name):
      if name not in self.secrets:
          return "Unknown secret"
      return self.secrets[name]

  def SetSecret(self, name, secret):
      self.secrets[name] = secret
      with open(os.path.expanduser('~/.kv-secrets'), 'wb') as f:
          pickle.dump(self.secrets, f, pickle.HIGHEST_PROTOCOL)
      return secret


bus = SystemBus()
bus.publish('net.minthe.SecretManager', SecretManager())
loop.run()
