#!/usr/bin/env python3
###############################################################################
# This is a script that interacts with the bundled SecretManager DBus service #
# and allows easy updating of pre-defined values.                             #
# Michael Kelley 8 July 2018                                                  #
###############################################################################

import pydbus
import json

bus = pydbus.SystemBus()
secret_manager = bus.get('net.minthe.SecretManager')
custom_fields = []
with open("custom_fields.json") as f:
    custom_fields = json.load(f)
custom_fields.append({'field_id': 'email', 'field_label': 'Email'})

command = ""

def helptext():
    print("L => List fields")
    print("U => Update a field")
    print("Q => Quit")
    print("H => Show this help text again")

def pretty_print_fields():
    for i, field in enumerate(custom_fields):
        print(str(i) + ") " + field['field_label'])

helptext()

while input is not "q":
    command = input("> ")

    if command == "":
        continue

    first_char = command[0].upper()
    if first_char == 'Q':
        break
    elif first_char == 'L':
        pretty_print_fields()
    elif first_char == 'U':
        pretty_print_fields()
        try:
            which_field = int(input("Number of the secret you wish to update: "))
        except:
            print("Please enter a number")
            pass
        if which_field >= len(custom_fields):
            print("Please enter a valid field number")
            continue
        new_secret = input("Enter the new value ")
        try:
            secret_manager.SetSecret(custom_fields[which_field]['field_id'], new_secret)
        except:
            print("There was a problem updating the secret. Please check your system configuration.")
            continue
        print(custom_fields[which_field]['field_label'] + " updated successfully.")






